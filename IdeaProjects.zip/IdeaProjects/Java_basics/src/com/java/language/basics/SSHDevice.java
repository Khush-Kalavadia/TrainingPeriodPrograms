package com.java.language.basics;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SSHDevice
{
    public static void fireExecSSHCommand(String username, String password, String host, int port, String command)
    {
        Session session = null;

        ChannelExec channel = null;

        try
        {
            session = new JSch().getSession(username, host, port);

            session.setPassword(password);

            session.setConfig("StrictHostKeyChecking", "no");       //accepts SSH host keys from remote servers and those not in the known host’s list.

            session.connect(10000);

            channel = (ChannelExec) session.openChannel("exec");

            channel.setCommand(command);

            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();

            channel.setOutputStream(responseStream);

            channel.connect(10000);

            while (channel.isConnected())
            {
                Thread.sleep(100);
            }

            String responseString = new String(responseStream.toByteArray());

            System.out.println(responseString);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            if (session != null)
            {
                session.disconnect();
            }
            if (channel != null)
            {
                channel.disconnect();       //Closing the channel will in turn cause the stream to be closed.
            }
        }
    }

    public static void fireShellSSHCommand(String username, String password, String host, int port, String commands)
    {
        Session session = null;

        Channel channel = null;

        BufferedWriter commandWriter = null;

        BufferedReader responseReader = null;

        try
        {
            session = new JSch().getSession(username, host, port);

            session.setPassword(password);

            session.setConfig("StrictHostKeyChecking", "no");       //accepts SSH host keys from remote servers and those not in the known host’s list.

            session.connect(10000);

            channel = session.openChannel("shell");

            channel.connect(10000);

            commandWriter = new BufferedWriter(new OutputStreamWriter(channel.getOutputStream()));

            responseReader = new BufferedReader(new InputStreamReader(channel.getInputStream()));

            commandWriter.write(commands);

            commandWriter.flush();

            String response;

            do
            {
                response = responseReader.readLine();

                System.out.println(response);
            }
            while (!response.contains("Linux"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            if (responseReader != null)
            {
                try
                {
                    responseReader.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            if (commandWriter != null)
            {
                try
                {
                    commandWriter.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            if (channel != null)
            {
                channel.disconnect();
            }
            if (session != null)
            {
                session.disconnect();
            }
        }
    }

    public static void fireGenericShellSSHCommand(String username, String password, String host, int port, List<String> commandList)
    {
        Session session = null;

        Channel channel = null;

        BufferedWriter commandWriter = null;

        BufferedReader responseReader = null;

        BufferedReader errorReader = null;

        try
        {
            session = new JSch().getSession(username, host, port);

            session.setPassword(password);

            session.setConfig("StrictHostKeyChecking", "no");       //accepts SSH host keys from remote servers and those not in the known host’s list.

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            System.out.println(dtf.format(now));

            session.connect(10000);


            now = LocalDateTime.now();
            System.out.println(dtf.format(now));


            channel = session.openChannel("shell");

            errorReader = new BufferedReader(new InputStreamReader(((ChannelExec) channel).getErrStream()));

            channel.connect(10000);

            while (errorReader.readLine() != null)
            {
                System.out.println(errorReader);
            }

            commandWriter = new BufferedWriter(new OutputStreamWriter(channel.getOutputStream()));

            responseReader = new BufferedReader(new InputStreamReader(channel.getInputStream()));

            StringBuilder commandConcat = new StringBuilder();

            for (String command : commandList)
            {
                commandConcat.append(command).append("\n");
            }

            commandWriter.write(commandConcat.toString());

            commandWriter.flush();

            String response;

            int commandIndex = 0;

            HashMap<String, String> responseMap = new HashMap<>();

            StringBuilder commandString;

            do
            {
                response = responseReader.readLine();
            }
            while (!response.contains(":~$ " + commandList.get(commandIndex)));

            commandIndex++;

            do
            {
                commandString = new StringBuilder();

                response = responseReader.readLine();

                while (!response.contains(":~$ " + commandList.get(commandIndex)))
                {
                    commandString.append(response.concat("\n"));

                    response = responseReader.readLine();
                }

                responseMap.put(commandList.get(commandIndex - 1), commandString.toString());

                commandIndex++;
            }
            while (commandIndex != commandList.size());

            System.out.println(responseMap);
        }
        catch (Exception ex)
        {

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            System.out.println(dtf.format(now));

            ex.printStackTrace();
        }
        finally
        {
            if (responseReader != null)
            {
                try
                {
                    responseReader.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            if (commandWriter != null)
            {
                try
                {
                    commandWriter.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            if (channel != null)
            {
                channel.disconnect();
            }
            if (session != null)
            {
                session.disconnect();
            }
        }
    }

    public static void main(String[] args)
    {
        try
        {
//            SSHDevice.fireExecSSHCommand("pavan", "Mind@123", "10.20.40.139", 22, "uname; ls\n ps");
//
//            SSHDevice.fireShellSSHCommand("pavan", "Mind@123", "10.20.40.139", 22, "ls\nps\nexit\nuname\n");

            List<String> commandList = new ArrayList<>();

            commandList.add("ls");

            commandList.add("uname");

            commandList.add("ping google.com -c 1");

            commandList.add("exit");

//            SSHDevice.fireGenericShellSSHCommand("pavan", "Mind@123", "10.20.40.139", 22, commandList);
//            SSHDevice.fireGenericShellSSHCommand("shekhar", "Mind@123", "10.20.42.142", 22, commandList);

            SSHDevice.fireGenericShellSSHCommand("pavan", "Mind@123", "10.20.40.139", 22, commandList);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
