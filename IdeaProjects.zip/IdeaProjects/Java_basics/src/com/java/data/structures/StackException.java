package com.java.data.structures;

public class StackException extends Exception
{
    public StackException(String message)
    {
        super(message);
    }
}
