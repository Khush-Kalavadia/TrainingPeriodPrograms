package com.java.concurrency;

public class CounterVolatile
{
    public volatile int value1 = 0;

    public volatile int value2 = 0;
}
