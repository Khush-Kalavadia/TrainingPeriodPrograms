let login = {
    getDataFromForm: function ()        //practically different jsp would have such functions which
        // would be evoked and at the end everything would be transfered to postajax call
    {
        $("form").submit(function (event)
        {
            event.preventDefault();

            //array.reduce(function(total, currentValue), initialValue)
            // let param = $('form').serializeArray().reduce(function(finalParam, currentValue) { finalParam[currentValue.name] = currentValue.value; return finalParam; }, {});
            let param = $('form').serialize();

            let request =
                {
                    url: "login",

                    param: param,

                    callback: login.getDataFromFormSuccess
                };

            ajaxCalls.ajaxPostCall(request);

        });
    },

    getDataFromFormSuccess: function (request)
    {
        if (request && request.bean && request.bean.login)
        {
            window.location.href = "mainPage";
        }
        else
        {
            let returnedObject = $("#loginUnsuccessfulAlert").html('<div class="alert alert-danger" role="alert"><strong>Incorrect login credentials!</strong> Check your username and password.</div></div>').show(100);

            setTimeout(function ()
            {
                returnedObject.slideUp(200);
            }, 3000);
        }
    },
};